const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const Book = require("./models/book");

const app = express();
const PORT = 3000;

// MongoDB Connection
mongoose.connect("mongodb://127.0.0.1:27017/libraryDB")
  .then(() => console.log("MongoDB Connected"))
  .catch(err => console.log(err));

app.use(bodyParser.urlencoded({ extended: true }));
app.set("view engine", "ejs");

// =======================
// HOME + SEARCH
// =======================
app.get("/", async (req, res) => {
  const search = req.query.search;
  let books;

  if (search) {
    books = await Book.find({
      title: { $regex: search, $options: "i" }
    });
  } else {
    books = await Book.find();
  }

  const totalBooks = await Book.countDocuments();
  const issuedBooks = await Book.countDocuments({ status: "Issued" });

  res.render("index", {
    books,
    totalBooks,
    issuedBooks,
    search
  });
});

// =======================
// ADD BOOK
// =======================
app.get("/add", (req, res) => {
  res.render("add");
});

app.post("/add", async (req, res) => {
  await Book.create({
    title: req.body.title,
    author: req.body.author,
    status: "Available"
  });

  res.redirect("/");
});

// =======================
// EDIT BOOK
// =======================
app.get("/edit/:id", async (req, res) => {
  const book = await Book.findById(req.params.id);
  res.render("edit", { book });
});

app.post("/edit/:id", async (req, res) => {
  await Book.findByIdAndUpdate(req.params.id, {
    title: req.body.title,
    author: req.body.author,
    status: req.body.status
  });

  res.redirect("/");
});

// =======================
// TOGGLE ISSUE/RETURN
// =======================
app.get("/toggle/:id", async (req, res) => {
  const book = await Book.findById(req.params.id);

  const newStatus = book.status === "Available" ? "Issued" : "Available";

  await Book.findByIdAndUpdate(req.params.id, {
    status: newStatus
  });

  res.redirect("/");
});

// =======================
// DELETE BOOK
// =======================
app.get("/delete/:id", async (req, res) => {
  await Book.findByIdAndDelete(req.params.id);
  res.redirect("/");
});

app.listen(PORT, () => {
  console.log(`Library App running at http://localhost:${PORT}`);
});